const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process'); // Used to spawn a Python process

const app = express();
const port = 8000;

// Ensure 'uploads' folder exists
if (!fs.existsSync('./boomi input')) {
    fs.mkdirSync('./boomi input');
    console.log('boomi input folder created');
}

// Set storage engine
const storage = multer.diskStorage({
    destination: './boomi input/', // Directory where files will be stored
    filename: (req, file, cb) => {
        // Use a custom name provided in the request body
        let customName = req.body.file; // Expecting 'filename' field in the request
        
     
        if (customName) {
            // Ensure the file extension matches the uploaded file's extension
            // customName = customName.replace(/[^a-zA-Z0-9.-_ ]/g, ""); // Sanitize file name (remove special characters except spaces, dots, underscores, and hyphens)
            customName = customName
            console.log(customName,'customName ')
            cb(null, customName + path.extname(file.originalname)); // Use custom name with the original extension
        } else {
            // Fall back to a generated name if no filename is provided
            cb(null, file.originalname );
        }
    }
});



// Initialize Upload for multiple files
const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // Limit file size to 5MB per file
    fileFilter: (req, file, cb) => {
        checkFileType(file, cb);
    }
});

// Middleware to handle multiple file uploads (up to 10 files)
const multipleFileUpload = upload.array('files', 10); // 'files' is the key in form-data

// Check file type
function checkFileType(file, cb) {
    const filetypes = /docx|xml|xlsx/; // Allowed file types
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);

    if (extname && mimetype) {
        return cb(null, true);
    } else {
        return cb(new Error('Please select only docx xml xlsx'));
    }
}

// Upload route for multiple files
app.post('/upload', (req, res) => {
    multipleFileUpload(req, res, (err) => {
        // Log request details for debugging
        console.log('Request received...');
        console.log('Files:', req.files); // Log all uploaded files
        console.log('Body:', req.body);   // Log additional form data

        if (err) {
            console.error('Error:', err.message);
            return res.status(400).json({ success: false, message: err.message });
        }

        if (!req.files || req.files.length === 0) {
            console.error('No files uploaded');
            return res.status(400).json({ success: false, message: 'No files uploaded!' });
        }

        const uploadedFiles = req.files.map(file => `boomi input/${file.originalname}`);

        console.log('Files uploaded successfully:', uploadedFiles);
        res.status(200).json({
            success: true,
            message: 'Files uploaded successfully!',
            files: uploadedFiles
        });
    });
});

// Serve uploaded files statically
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));




// Ensure the "boomi input" folder exists
const inputFolderPath = path.join(__dirname, 'boomi input');
if (!fs.existsSync(inputFolderPath)) {
    fs.mkdirSync(inputFolderPath, { recursive: true });
    console.log(`✅ Created input folder: ${inputFolderPath}`);
} else {
    console.log(`ℹ️ Input folder already exists: ${inputFolderPath}`);
}

// Create config.json for Python script
const configFilePath = path.join(__dirname, 'config.json');
const config = { inputFolder: inputFolderPath };

fs.writeFileSync(configFilePath, JSON.stringify(config, null, 2), 'utf-8');
console.log(`✅ Config file saved to: ${configFilePath}`);

// API endpoint to run the Python script
app.get('/migrate', (req, res) => {
    console.log('📢 Running Python script...');

    // Spawn a Python process and pass the config path as an argument
    const pythonProcess = spawn('python', ['script.py']); // Adjust to 'python3' if necessary on Linux/Mac

    let output = '';

    // Capture the output from the Python script
    pythonProcess.stdout.on('data', (data) => {
        output += data.toString(); // Collect stdout data
    });

    // Capture any error output from the Python script
    pythonProcess.stderr.on('data', (data) => {
        console.error(`stderr: ${data}`);
    });

    //When the Python script finishes
    pythonProcess.on('close', (code) => {
        if (code === 0) {
            res.status(200).send(`Python script output:\n${output}`);
        } else {
            res.status(500).send(`Python script failed with code ${code}`);
        }
    });
    // pythonProcess.on('close', (code) => {
    //     try {
    //         // Attempt to parse the output string as JSON
    //         const jsonOutput = JSON.parse(output);  // Convert string to JSON
    
    //         // Handle the parsed JSON
    //         console.log("Parsed JSON:", jsonOutput);
    //     } catch (error) {
    //         console.error('Failed to parse output as JSON:', error);
    //         console.log('Raw output:', output);  // Log raw output in case of error
    //     }
    // });
});

// Health check route
app.get('/status', (req, res) => {
    res.status(200).json({
        success: true,
        message: 'App is running!',
        timestamp: new Date().toISOString()
    });
});

// Start the Express server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
