import os
import json
from anthropic import Anthropic
import xml.dom.minidom
import traceback
import pandas as pd
from docx import Document
import openpyxl

class BoomiToMuleConverter:
    def __init__(self, api_key, input_folder_path):
        self.client = Anthropic(api_key=api_key)
        self.input_folder = input_folder_path
        self.output_folder = os.path.join(os.path.dirname(input_folder_path), "mule_output")
        
        if not os.path.exists(self.output_folder):
            os.makedirs(self.output_folder)

    def find_master_xml(self, filename):
        """Check if file is a master XML based on filename"""
        return 'master' in filename.lower()

    def read_all_files(self):
        """Read and categorize all relevant files"""
        files_content = {
            'master_xml': None,
            'child_xmls': {},
            'mapping_excel': None,
            'documentation': None
        }

        print("\nReading files:")
        master_found = False
        
        for filename in os.listdir(self.input_folder):
            file_path = os.path.join(self.input_folder, filename)
            if not os.path.isfile(file_path):
                continue

            try:
                # XML files
                if filename.endswith('.xml'):
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        
                    if self.find_master_xml(filename) and not master_found:
                        files_content['master_xml'] = {
                            'content': content,
                            'path': file_path
                        }
                        master_found = True
                        print(f"[OK] Read master XML: {filename}")
                    else:
                        files_content['child_xmls'][filename] = {
                            'content': content,
                            'path': file_path
                        }
                        print(f"[OK] Read child XML: {filename}")

                # Mapping Excel files
                elif filename.endswith(('.xlsx', '.xls')):
                    try:
                        excel_data = pd.read_excel(file_path, sheet_name=None)
                        if not files_content['mapping_excel']:  # Take the first Excel file found
                            files_content['mapping_excel'] = {
                                'content': excel_data,
                                'path': file_path
                            }
                            print(f"[OK] Read mapping Excel: {filename}")
                    except Exception as e:
                        print(f"[ERROR] Error reading Excel {filename}: {str(e)}")

                # Documentation files
                elif filename.endswith('.docx'):
                    try:
                        doc = Document(file_path)
                        doc_text = "\n".join([paragraph.text for paragraph in doc.paragraphs])
                        if not files_content['documentation']:  # Take the first Word doc found
                            files_content['documentation'] = {
                                'content': doc_text,
                                'path': file_path
                            }
                            print(f"[OK] Read documentation: {filename}")
                    except Exception as e:
                        print(f"[ERROR] Error reading Word doc {filename}: {str(e)}")

            except Exception as e:
                print(f"[ERROR] Error reading {filename}: {str(e)}")
                continue

        return files_content

    def create_claude_prompt(self, files_content):
        """Create comprehensive prompt including all file contents"""
        prompt = """You are a Boomi to Mule 4 migration expert. Please analyze all the provided files and generate an equivalent Mule 4 implementation.

Requirements:
1. Convert the Boomi processes to Mule 4.x flows
2. Use any available mapping documents for data transformations
3. Follow the high-level flow understanding from any provided documentation
4. Maintain all integration patterns and business logic
5. Include proper error handling and logging
6. Follow Mule 4 best practices

Here are the source files:"""

        # Add master XML
        if files_content['master_xml']:
            prompt += f"\n\nMASTER PROCESS XML:\n```xml\n{files_content['master_xml']['content']}\n```\n"

        # Add child XMLs
        if files_content['child_xmls']:
            prompt += "\nRELATED CHILD PROCESSES:"
            for name, content in files_content['child_xmls'].items():
                prompt += f"\n\nChild Process: {name}\n```xml\n{content['content']}\n```"

        # Add mapping information if available
        if files_content['mapping_excel']:
            prompt += "\n\nMAPPING DETAILS:"
            for sheet_name, df in files_content['mapping_excel']['content'].items():
                prompt += f"\n\nSheet: {sheet_name}\n{df.to_string()}"

        # Add documentation if available
        if files_content['documentation']:
            prompt += f"\n\nFLOW DOCUMENTATION:\n{files_content['documentation']['content']}"

        prompt += """

Please generate:
1. Complete Mule 4 XML configuration
2. DataWeave transformations for any required mappings
3. Error handling and retry mechanisms
4. Comments explaining the conversion decisions

Return the Mule 4 XML configuration that implements this integration."""
        
        # Save prompt for debugging
        debug_path = os.path.join(self.output_folder, "debug_prompt.txt")
        with open(debug_path, 'w', encoding='utf-8') as f:
            f.write(prompt)
        print(f"\nDebug prompt saved to: {debug_path}")
        
        return prompt

    def generate_mule_xml(self, files_content):
        """Generate Mule XML using Claude API"""
        prompt = self.create_claude_prompt(files_content)
        
        try:
            print("\nSending request to Claude API...")
            message = self.client.messages.create(
                model="claude-3-opus-20240229",
                max_tokens=2048,
                temperature=0,
                messages=[{
                    "role": "user",
                    "content": prompt
                }]
            )
            
            print("Received response from Claude API")
            
            # Save raw response for debugging
            debug_path = os.path.join(self.output_folder, "debug_response.txt")
            with open(debug_path, 'w', encoding='utf-8') as f:
                f.write(str(message.content))
            print(f"Debug response saved to: {debug_path}")
            
            # Extract XML content from Claude's response
            response_text = message.content[0].text
            
            # Try to find XML content between code blocks
            xml_start = response_text.find('```xml')
            xml_end = response_text.find('```', xml_start + 6)
            
            if xml_start != -1 and xml_end != -1:
                mule_xml = response_text[xml_start + 6:xml_end].strip()
            else:
                # Try to find content between <?xml and </mule>
                xml_start = response_text.find('<?xml')
                xml_end = response_text.find('</mule>') + 7
                if xml_start != -1 and xml_end != -1:
                    mule_xml = response_text[xml_start:xml_end].strip()
                else:
                    raise Exception("Could not find valid XML content in response")
            
            # Clean up and format XML
            if "<?xml" not in mule_xml:
                mule_xml = '<?xml version="1.0" encoding="UTF-8"?>\n' + mule_xml
                
            # Format XML using minidom
            print("Formatting XML...")
            dom = xml.dom.minidom.parseString(mule_xml)
            formatted_xml = dom.toprettyxml(indent="    ")
            
            return formatted_xml
            
        except Exception as e:
            print(f"\nError generating Mule XML:")
            print(f"Error type: {type(e).__name__}")
            print(f"Error message: {str(e)}")
            print("\nFull traceback:")
            traceback.print_exc()
            
            # Try alternative models if the first one fails
            alternative_models = [
                "claude-3-haiku-20240307",
                "claude-3-sonnet-20240229",
                "claude-2.1"
            ]
            
            for model in alternative_models:
                try:
                    print(f"\nTrying alternative model: {model}")
                    message = self.client.messages.create(
                        model=model,
                        max_tokens=4096,
                        temperature=0,
                        messages=[{
                            "role": "user",
                            "content": prompt
                        }]
                    )
                    print(f"Successfully connected using model: {model}")
                    return message.content[0].text
                except Exception as e2:
                    print(f"Error with model {model}: {str(e2)}")
                    continue
                    
            return None

    def save_mule_xml(self, mule_xml):
        """Save the generated Mule XML"""
        # Generate output filename based on master XML name if available
        output_filename = "mule-output.xml"
        if hasattr(self, 'master_file'):
            base_name = os.path.splitext(self.master_file)[0]
            output_filename = f"mule-{base_name}.xml"
            
        output_path = os.path.join(self.output_folder, output_filename)
        try:
            with open(output_path, 'w', encoding='utf-8') as file:
                file.write(mule_xml)
            print(f"\nMule XML saved successfully to: {output_path}")
            return output_path
        except Exception as e:
            print(f"\nError saving Mule XML:")
            print(f"Error type: {type(e).__name__}")
            print(f"Error message: {str(e)}")
            print("\nFull traceback:")
            traceback.print_exc()
            return None

    def convert(self):

        """Main conversion process"""
        print(f"\nStarting conversion process...")
        print(f"Input folder: {self.input_folder}")
        print(f"Output folder: {self.output_folder}")
        
        # Read all files
        files_content = self.read_all_files()
        
        if not files_content['master_xml']:
            print("\nNo master XML file found! Looking for XML file with 'master' in the name.")
            return

        print(f"\nFound:")
        print(f"- {'1' if files_content['master_xml'] else '0'} master XML")
        print(f"- {len(files_content['child_xmls'])} child XMLs")
        print(f"- {'1' if files_content['mapping_excel'] else '0'} mapping Excel")
        print(f"- {'1' if files_content['documentation'] else '0'} documentation file")
        
        # Generate Mule XML
        print("\nGenerating Mule XML...")
        mule_xml = self.generate_mule_xml(files_content)
        
        if mule_xml:
            output_path = self.save_mule_xml(mule_xml)
            if output_path:
                print(f"\nConversion completed successfully!")
                print(f"Output saved to: {output_path}")
        else:
            print("\nFailed to generate Mule XML")


def get_input_folder():
    """Read the input folder path from config.json"""
    config_path = os.path.join(os.path.dirname(__file__), "config.json")
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
            return config.get("inputFolder", "")
    except Exception as e:
        print(f"❌ Error reading config.json: {str(e)}")
        return None


def main():
    # Your Claude API key
    api_key = "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"
    
    # Dynamically get the input folder path from config.json
    input_folder_path = get_input_folder()
    if not input_folder_path:
        print("❌ No input folder specified. Ensure config.json exists and contains the input folder path.")
        return
    
    try:
        converter = BoomiToMuleConverter(api_key, input_folder_path)
        converter.convert()
    except Exception as e:
        print("\nCritical error in main:")
        print(f"Error type: {type(e).__name__}")
        print(f"Error message: {str(e)}")
        print("\nFull traceback:")
        traceback.print_exc()


if __name__ == "__main__":
    main()