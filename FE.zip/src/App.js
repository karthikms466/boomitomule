import React from 'react';
import './App.css';
import { Upload, FileText, Check, AlertCircle, RefreshCw } from 'lucide-react';
import { useState, useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from 'axios';
// API configuration
const API_BASE_URL = 'http://localhost:8000'; // Backend server URL

function BoomiToMuleConverter() {
  const [files, setFiles] = React.useState([]);
  const [converting, setConverting] = React.useState(false);
  const [result, setResult] = React.useState(null);
  const [error, setError] = React.useState(null);
  const [health, setHealth] = React.useState('');
  const [migrating, setMigrating] = React.useState(false);
  const [migrateResult, setMigrateResult] = React.useState(null);
  const [warningMessage, setWarningMessage] = React.useState(''); // New state for warning message


  const [isLoading, setIsLoading] = useState(false);
  // Check API health on component mount
  React.useEffect(() => {
    checkApiHealth();
  }, []);

  const checkApiHealth = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/status`);
      if (!response.ok) {
        setHealth('API health check failed');
        console.warn('API health check failed');
      } else {
        setHealth('App Live');
      }
    } catch (err) {
      console.error('API connection error:', err);
      setHealth('App Disconnected');
    }
  };

  const onFileChange = React.useCallback((e) => {
    const selectedFiles = Array.from(e.target.files);
    // Validate file types
    const invalidFiles = selectedFiles.filter(file => {
      const ext = file.name.toLowerCase().split('.').pop();
      return !['xml', 'xlsx', 'xls', 'docx'].includes(ext);
    });

    if (invalidFiles.length > 0) {
      setError('Invalid file type. Only XML, Excel, and Word files are allowed.');
      return;
    }

    setFiles(prevFiles => [...prevFiles, ...selectedFiles]);
    setError(null);
    setWarningMessage('');  // Reset warning message when files are uploaded
  }, []);

  const removeFile = React.useCallback((fileName) => {
    setFiles(prevFiles => prevFiles.filter(file => file.name !== fileName));
  }, []);

  const startConversion = async () => {
    if (files.length === 0) {
      setWarningMessage('Please upload files before starting conversion!');
      return;
    }

    setConverting(true);
    setError(null);
    setResult(null);

    try {
      const formData = new FormData();
      files.forEach(file => {
        formData.append('files', file);
      });

      const response = await fetch(`${API_BASE_URL}/upload`, {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || `File upload failed: ${response.statusText}`);
      }

      const data = await response.json();
      setResult(data);
    } catch (err) {
      setError(err.message);
      console.error('Conversion error:', err);
    } finally {
      setConverting(false);
    }
  };
  const migrateFilesaxios = async () => {
    if (files.length === 0) {
      setWarningMessage('Please upload files before starting migration!');
      return;
    }
  
    setMigrating(true);
    setMigrateResult(null);
  
    try {
      const response = await axios.get(`${API_BASE_URL}/migrate`);
       
      // If the response is successful, you can directly use response.data
      setMigrateResult(response.data);  // Axios automatically parses the response as JSON
      console.log(response.data,'ddddddddddddd')
    } catch (err) {
      // Handle error properly
      if (err.response) {
        // Server responded with a status code outside the 2xx range
        setError(err.response.data.message || `Migration failed: ${err.response.statusText}`);
      } else if (err.request) {
        // No response received
        setError('No response from server');
      } else {
        // Error setting up the request
        setError('Error during migration request setup');
      }
      console.error('Migration error:', err);
    } finally {
      setMigrating(false);
    }
  };
  // const migrateFiles = async () => {
  //   if (files.length === 0) {
  //     setWarningMessage('Please upload files before starting migration!');
  //     return;
  //   }

  //   setMigrating(true);
  //   setMigrateResult(null);

  //   try {
  //     const response = await fetch(`${API_BASE_URL}/migrate`);

  //     if (!response.ok) {
  //       const errorData = await response.json();
  //       throw new Error(errorData.message || `Migration failed: ${response.statusText}`);
  //     }
  //     const data = await response.text();
  //     setMigrateResult(data);
  //   } catch (err) {
  //     setError(err.message);
  //     console.error('Migration error:', err);
  //   } finally {
  //     setMigrating(false);
  //   }
  // }

  const resetAll = () => {
    setFiles([]);
    setResult(null);
    setError(null);
    setMigrateResult(null);
    setWarningMessage(''); // Reset warning message on reset
  };

  // Handle drag and drop
  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.classList.add('drag-active');
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.classList.remove('drag-active');
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    e.currentTarget.classList.remove('drag-active');

    const droppedFiles = Array.from(e.dataTransfer.files);
    const invalidFiles = droppedFiles.filter(file => {
      const ext = file.name.toLowerCase().split('.').pop();
      return !['xml', 'xlsx', 'xls', 'docx'].includes(ext);
    });

    if (invalidFiles.length > 0) {
      setError('Invalid file type. Only XML, Excel, and Word files are allowed.');
      return;
    }

    setFiles(prevFiles => [...prevFiles, ...droppedFiles]);
    setError(null);
    setWarningMessage('');  // Reset warning message on file upload
  };

   // Handle migration process


  return (
    <div className="converter-container">
      <div className="converter-card">
        <div className="converter-header">
          <p>{health}</p>
          <h2>Boomi to Mule Converter</h2>
          <p>Upload your Boomi files to convert them to Mule 4 format</p>
        </div>

        <div className="converter-content">
          {/* File Upload Section */}
          <div 
            className="upload-area"
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <input
              type="file"
              multiple
              onChange={onFileChange}
              className="file-input"
              id="file-upload"
              accept=".xml,.xlsx,.xls,.docx"
            />
            <label htmlFor="file-upload" className="upload-label">
              <Upload className="upload-icon" />
              <span className="upload-text">
                Click to upload or drag and drop files here
              </span>
              <span className="upload-hint">
                Supports XML, Excel (xlsx/xls), and Word (docx) files
              </span>
            </label>
          </div>

          {/* Warning Message */}
          {warningMessage && (
            <div className="warning-message">
              <AlertCircle className="message-icon" />
              <span>{warningMessage}</span>
            </div>
          )}

          {/* File List */}
          {files.length > 0 && (
            <div className="file-list">
              <h3>Uploaded Files:</h3>
              {files.map(file => (
                <div key={file.name} className="file-item">
                  <div className="file-info">
                    <FileText className="file-icon" />
                    <span>{file.name}</span>
                  </div>
                  {/* <button
                    onClick={() => removeFile(file.name)}
                    className="remove-button"
                    aria-label="Remove file"
                  >
                    Remove
                  </button> */}
                </div>
              ))}
            </div>
          )}

          {/* Action Buttons */}
          <div className="action-buttons">
            <button
              onClick={resetAll}
              disabled={converting || (!files.length && !result)}
              className="reset-button"
            >
              Reset
            </button>
            <button
              onClick={startConversion}
              disabled={converting || !files.length}
              className="convert-button"
            >
              {converting ? (
                <>
                  <RefreshCw className="spinner" />
                  Converting...
                </>
              ) : (
                <>
                  <Upload className="button-icon" />
                  Load Files
                </>
              )}
            </button>
            {result && (
              <button
                onClick={migrateFilesaxios}
                disabled={migrating || !files.length}
                className="migrate-button"
              >
                {migrating ? (
                  <>
                    <RefreshCw className="spinner" />
                    Migrating...
                  </>
                ) : (
                  <>
                    <Upload className="button-icon" />
                    Migrate Files
                  </>
                )}
              </button>
            )}
          </div>

          {/* Error Display */}
          {error && (
            <div className="error-message">
              <AlertCircle className="message-icon" />
              <span>{error}</span>
            </div>
          )}

          {/* Success Result */}
          {result && (
            <div className="success-message">
              <Check className="message-icon" />
              <span>File loaded successfully: {result.outputPath}</span>
            </div>
          )}

          {/* Migration Result */}
          {migrateResult && (
            <div className="success-message">
              <Check className="message-icon" />
              <span>Migration completed successfully {migrateResult.message}</span>
            </div>
          )}
        </div>
        {migrateResult}
      </div>

      {/* Conversion Details */}
    
    </div>
  );
}

function App() {
  return (
    <div className="app">
      <header className="app-header"></header>
      <main className="app-main">
        <BoomiToMuleConverter />
      </main>
    </div>
  );
}

export default App;
